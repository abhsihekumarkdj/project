from django.contrib import admin
from django.urls import path,include
from Poll import views

urlpatterns = [
    path('admin/', admin.site.urls),
    path('create/',include(create.urls)),
    path('home',include(home.urls)),
    path('vote/<poll_id>/',include(vote.urls)),
    
    ]