from datetime import timedelta
from django.db import models
from django.utils.timezone import now

class Poll(models.Model):
    email = Poll.CharField(max_length=30)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return 'code: ' + str(self.code)

    @property
    def deletes_in_ten_seconds(self):
        time = self.created_at + timedelta(seconds=10)
        query = Poll.objects.get(pk=self.pk)
        if time > now():
            query.delete()